# World Cup Soccer 2026 — Godot 4

A playable 2D World Cup-style soccer prototype made entirely with Godot 4 GDScript.
No external art assets are required.

## Run
1. Install Godot 4.x.
2. Open `project.godot` with Godot.
3. Press Play.

## Controls
- WASD: move controlled player
- Space: shoot
- Tab: switch to the home player closest to the ball
- P: pause
- R: rematch after full time
- Esc: return to menu
- Enter: start match

## Included
- Team selection menu
- Six national teams
- 3v3 playable match
- Soccer pitch and goals drawn by code
- Score and match clock
- Player switching
- Opponent AI
- Ball physics, passing/nudging and shooting
- Goal detection and kickoff reset
- Simplified offside rule
- Pause, full-time and rematch states

## Important
This is a complete playable foundation, not a licensed FIFA/EA game. Team names are used for the game prototype; official crests, player likenesses, tournament branding and licensed assets should only be added when you have permission to use them.
