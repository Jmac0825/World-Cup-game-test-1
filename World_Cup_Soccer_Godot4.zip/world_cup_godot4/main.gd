extends Node2D

const FIELD := Rect2(70, 100, 1140, 560)
const GOAL_W := 24.0
const MATCH_LENGTH := 90.0
const PLAYER_SPEED := 285.0
const BALL_MAX_SPEED := 950.0

var teams = ["Spain", "Argentina", "France", "England", "Brazil", "Germany"]
var team_colors = {
    "Spain": Color("#E63946"),
    "Argentina": Color("#75BFE8"),
    "France": Color("#173F8A"),
    "England": Color("#F4F4F4"),
    "Brazil": Color("#F2C94C"),
    "Germany": Color("#202020")
}

var home_team := "Spain"
var away_team := "Argentina"
var home_score := 0
var away_score := 0
var time_left := MATCH_LENGTH
var paused := false
var game_over := false
var menu := true
var message := ""
var message_time := 0.0

var players: Array = []
var controlled_index := 0
var ball_pos := Vector2.ZERO
var ball_vel := Vector2.ZERO
var last_touch_team := ""
var shot_cooldown := 0.0
var ai_kick_cooldown := 0.0
var kickoff_timer := 0.0

func _ready():
    queue_redraw()

func _process(delta):
    if menu:
        queue_redraw()
        return
    if paused or game_over:
        queue_redraw()
        return

    time_left -= delta
    message_time = max(0.0, message_time - delta)
    shot_cooldown = max(0.0, shot_cooldown - delta)
    ai_kick_cooldown = max(0.0, ai_kick_cooldown - delta)
    kickoff_timer = max(0.0, kickoff_timer - delta)

    if time_left <= 0:
        time_left = 0
        game_over = true
        message = "FULL TIME"

    update_players(delta)
    update_ball(delta)
    check_goals()
    queue_redraw()

func start_match():
    menu = false
    paused = false
    game_over = false
    home_score = 0
    away_score = 0
    time_left = MATCH_LENGTH
    message = ""
    players.clear()

    # Three players per team: enough for a playable compact match.
    players.append(make_player(Vector2(FIELD.position.x + 180, FIELD.position.y + 180), true, 0))
    players.append(make_player(Vector2(FIELD.position.x + 250, FIELD.get_center().y), true, 1))
    players.append(make_player(Vector2(FIELD.position.x + 180, FIELD.position.y + 380), true, 2))

    players.append(make_player(Vector2(FIELD.end.x - 180, FIELD.position.y + 180), false, 0))
    players.append(make_player(Vector2(FIELD.end.x - 250, FIELD.get_center().y), false, 1))
    players.append(make_player(Vector2(FIELD.end.x - 180, FIELD.position.y + 380), false, 2))

    controlled_index = 1
    reset_kickoff(true)
    queue_redraw()

func make_player(pos: Vector2, home: bool, number: int) -> Dictionary:
    return {
        "pos": pos,
        "home": home,
        "number": number + 1,
        "vel": Vector2.ZERO,
        "stamina": 100.0
    }

func reset_kickoff(home_kick: bool):
    for p in players:
        if p.home:
            p.pos.x = FIELD.position.x + 170 + p.number * 35
        else:
            p.pos.x = FIELD.end.x - 170 - p.number * 35
        p.pos.y = FIELD.get_center().y + (p.number - 2) * 120
        p.vel = Vector2.ZERO

    ball_pos = FIELD.get_center()
    ball_vel = Vector2.ZERO
    last_touch_team = ""
    kickoff_timer = 0.8

func update_players(delta):
    if players.is_empty():
        return

    var target = players[controlled_index]
    var input_dir = Input.get_vector("move_left", "move_right", "move_up", "move_down")
    target.vel = input_dir * PLAYER_SPEED
    target.pos += target.vel * delta
    target.pos = clamp_to_field(target.pos, 18)

    if Input.is_action_just_pressed("switch_player"):
        controlled_index = nearest_home_player_to_ball()

    if Input.is_action_just_pressed("shoot") and shot_cooldown <= 0 and kickoff_timer <= 0:
        try_kick(true)

    # Simple opponent AI.
    for i in range(players.size()):
        if i == controlled_index:
            continue
        var p = players[i]
        if p.home:
            # Teammates loosely support the ball.
            var desired = ball_pos + Vector2(-65, (i - 1) * 110)
            p.vel = (desired - p.pos).normalized() * PLAYER_SPEED * 0.65
        else:
            var desired = ball_pos + Vector2(70, (i - 1) * 100)
            p.vel = (desired - p.pos).normalized() * PLAYER_SPEED * 0.72
        p.pos += p.vel * delta
        p.pos = clamp_to_field(p.pos, 18)

        if not p.home and p.pos.distance_to(ball_pos) < 30 and ai_kick_cooldown <= 0:
            ai_kick()

func nearest_home_player_to_ball() -> int:
    var best := controlled_index
    var best_d := INF
    for i in range(players.size()):
        if players[i].home:
            var d = players[i].pos.distance_to(ball_pos)
            if d < best_d:
                best_d = d
                best = i
    return best

func try_kick(is_human: bool):
    var p = players[controlled_index]
    if p.pos.distance_to(ball_pos) > 55:
        return

    if is_offside(p):
        message = "OFFSIDE"
        message_time = 1.2
        ball_vel = Vector2.ZERO
        return

    var aim := Vector2(1, 0)
    if p.home:
        aim = Vector2(1, 0)
    else:
        aim = Vector2(-1, 0)

    # Aim toward the center of the opponent goal, with a little vertical control.
    var goal_center = Vector2(FIELD.end.x, FIELD.get_center().y) if p.home else Vector2(FIELD.position.x, FIELD.get_center().y)
    aim = (goal_center - p.pos).normalized()
    ball_vel = aim * BALL_MAX_SPEED
    ball_pos += aim * 25
    last_touch_team = home_team if p.home else away_team
    shot_cooldown = 0.25

func ai_kick():
    ai_kick_cooldown = 0.65
    var nearest = 0
    var best = INF
    for i in range(players.size()):
        if not players[i].home:
            var d = players[i].pos.distance_to(ball_pos)
            if d < best:
                best = d
                nearest = i
    var p = players[nearest]
    if is_offside(p):
        return
    var target = Vector2(FIELD.position.x, FIELD.get_center().y + randf_range(-90, 90))
    ball_vel = (target - p.pos).normalized() * 700.0
    last_touch_team = away_team

func is_offside(p: Dictionary) -> bool:
    # Simplified law: a player is offside in the opponent half if ahead of
    # the second-last opponent and closer to goal than the ball at the moment of kick.
    var attacking_home = p.home
    var halfway = FIELD.get_center().x
    if attacking_home and p.pos.x <= halfway:
        return false
    if not attacking_home and p.pos.x >= halfway:
        return false

    var defenders: Array[float] = []
    for q in players:
        if q.home != attacking_home:
            defenders.append(q.pos.x)
    defenders.sort()

    if defenders.size() < 2:
        return false

    var second_last_x = defenders[-2] if attacking_home else defenders[1]
    if attacking_home:
        return p.pos.x > second_last_x and p.pos.x > ball_pos.x
    else:
        return p.pos.x < second_last_x and p.pos.x < ball_pos.x

func update_ball(delta):
    if kickoff_timer > 0:
        return

    ball_pos += ball_vel * delta
    ball_vel = ball_vel.move_toward(Vector2.ZERO, 650.0 * delta)

    # Players can nudge the ball.
    for p in players:
        var d = p.pos.distance_to(ball_pos)
        if d < 27:
            var push = (ball_pos - p.pos).normalized()
            if push.length() < 0.5:
                push = Vector2.RIGHT
            ball_pos += push * 2.5
            ball_vel += push * 80
            ball_vel = ball_vel.limit_length(BALL_MAX_SPEED)
            last_touch_team = home_team if p.home else away_team

    var top := FIELD.position.y + 10
    var bottom := FIELD.end.y - 10
    if ball_pos.y < top:
        ball_pos.y = top
        ball_vel.y *= -0.85
    if ball_pos.y > bottom:
        ball_pos.y = bottom
        ball_vel.y *= -0.85

    # Side boundaries; leave the goal mouth open.
    if ball_pos.x < FIELD.position.x and abs(ball_pos.y - FIELD.get_center().y) > 62:
        ball_pos.x = FIELD.position.x
        ball_vel.x *= -0.85
    if ball_pos.x > FIELD.end.x and abs(ball_pos.y - FIELD.get_center().y) > 62:
        ball_pos.x = FIELD.end.x
        ball_vel.x *= -0.85

func check_goals():
    if ball_pos.x < FIELD.position.x - GOAL_W and abs(ball_pos.y - FIELD.get_center().y) < 60:
        away_score += 1
        message = "GOAL! " + away_team
        message_time = 2.0
        reset_kickoff(false)
    elif ball_pos.x > FIELD.end.x + GOAL_W and abs(ball_pos.y - FIELD.get_center().y) < 60:
        home_score += 1
        message = "GOAL! " + home_team
        message_time = 2.0
        reset_kickoff(true)

func clamp_to_field(pos: Vector2, margin: float) -> Vector2:
    return Vector2(
        clamp(pos.x, FIELD.position.x + margin, FIELD.end.x - margin),
        clamp(pos.y, FIELD.position.y + margin, FIELD.end.y - margin)
    )

func _input(event):
    if event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_P:
            paused = !paused
        elif event.keycode == KEY_ESCAPE:
            menu = true
            game_over = false
        elif event.keycode == KEY_R and game_over:
            start_match()
        elif menu and event.keycode == KEY_ENTER:
            start_match()

func _draw():
    if menu:
        draw_menu()
    else:
        draw_match()

func draw_menu():
    draw_rect(Rect2(0, 0, 1280, 720), Color("#07131f"))
    draw_circle(Vector2(640, 155), 90, Color("#0d2a3e"))
    draw_circle(Vector2(640, 155), 65, Color("#123e59"))
    draw_string(ThemeDB.fallback_font, Vector2(350, 85), "WORLD CUP SOCCER", HORIZONTAL_ALIGNMENT_LEFT, -1, 48, Color.WHITE)
    draw_string(ThemeDB.fallback_font, Vector2(455, 125), "GODOT 4 EDITION", HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color("#b8d7e8"))

    draw_string(ThemeDB.fallback_font, Vector2(90, 245), "SELECT TEAMS", HORIZONTAL_ALIGNMENT_LEFT, -1, 28, Color.WHITE)
    for i in range(teams.size()):
        var x = 90 + (i % 3) * 360
        var y = 295 + (i / 3) * 105
        var selected = teams[i] == home_team or teams[i] == away_team
        draw_rect(Rect2(x, y, 310, 75), Color("#19364a") if selected else Color("#102536"), true)
        draw_circle(Vector2(x + 38, y + 38), 15, team_colors[teams[i]])
        draw_string(ThemeDB.fallback_font, Vector2(x + 70, y + 47), teams[i], HORIZONTAL_ALIGNMENT_LEFT, -1, 24, Color.WHITE)

    draw_string(ThemeDB.fallback_font, Vector2(90, 545), "Home: " + home_team + "    Away: " + away_team, HORIZONTAL_ALIGNMENT_LEFT, -1, 26, Color("#f4d35e"))
    draw_string(ThemeDB.fallback_font, Vector2(90, 590), "WASD Move   SPACE Shoot   TAB Switch Player   P Pause   ESC Menu", HORIZONTAL_ALIGNMENT_LEFT, -1, 19, Color("#c8d6df"))
    draw_string(ThemeDB.fallback_font, Vector2(90, 635), "Press ENTER to start", HORIZONTAL_ALIGNMENT_LEFT, -1, 30, Color.WHITE)

func draw_match():
    draw_rect(Rect2(0, 0, 1280, 720), Color("#07131f"))
    draw_rect(Rect2(0, 0, 1280, 78), Color("#0d2435"))

    # Pitch
    draw_rect(FIELD, Color("#2e8b57"))
    for i in range(10):
        var stripe = Rect2(FIELD.position.x + i * FIELD.size.x / 10.0, FIELD.position.y,
            FIELD.size.x / 10.0, FIELD.size.y)
        if i % 2 == 0:
            draw_rect(stripe, Color(0.13, 0.48, 0.29, 0.25))

    draw_rect(FIELD, Color.WHITE, false, 4)
    draw_line(Vector2(FIELD.get_center().x, FIELD.position.y), Vector2(FIELD.get_center().x, FIELD.end.y), Color.WHITE, 3)
    draw_circle(FIELD.get_center(), 78, Color.WHITE, false, 3)
    draw_circle(FIELD.get_center(), 5, Color.WHITE)

    # Penalty areas and goals.
    var left_box = Rect2(FIELD.position.x, FIELD.get_center().y - 115, 175, 230)
    var right_box = Rect2(FIELD.end.x - 175, FIELD.get_center().y - 115, 175, 230)
    draw_rect(left_box, Color.WHITE, false, 3)
    draw_rect(right_box, Color.WHITE, false, 3)
    draw_rect(Rect2(FIELD.position.x - GOAL_W, FIELD.get_center().y - 60, GOAL_W, 120), Color("#dfe7ea"), true)
    draw_rect(Rect2(FIELD.end.x, FIELD.get_center().y - 60, GOAL_W, 120), Color("#dfe7ea"), true)

    # Players.
    for i in range(players.size()):
        var p = players[i]
        var c = team_colors[home_team if p.home else away_team]
        draw_circle(p.pos, 19, Color(0, 0, 0, 0.35))
        draw_circle(p.pos, 16, c)
        draw_circle(p.pos, 16, Color.WHITE, false, 2)
        if i == controlled_index:
            draw_arc(p.pos, 23, 0, TAU, 32, Color("#f4d35e"), 3)
        draw_string(ThemeDB.fallback_font, p.pos + Vector2(-6, 7), str(p.number), HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color.WHITE)

    # Ball.
    draw_circle(ball_pos, 9, Color("#111820"))
    draw_circle(ball_pos, 7, Color.WHITE)
    draw_circle(ball_pos, 7, Color.WHITE, false, 1)

    # HUD.
    draw_string(ThemeDB.fallback_font, Vector2(55, 48), home_team, HORIZONTAL_ALIGNMENT_LEFT, -1, 27, Color.WHITE)
    draw_string(ThemeDB.fallback_font, Vector2(590, 48), "%02d:%02d" % [int(time_left) / 60, int(time_left) % 60], HORIZONTAL_ALIGNMENT_LEFT, -1, 27, Color.WHITE)
    draw_string(ThemeDB.fallback_font, Vector2(690, 48), str(home_score) + "  -  " + str(away_score), HORIZONTAL_ALIGNMENT_LEFT, -1, 30, Color("#f4d35e"))
    draw_string(ThemeDB.fallback_font, Vector2(965, 48), away_team, HORIZONTAL_ALIGNMENT_LEFT, -1, 27, Color.WHITE)

    if paused:
        draw_rect(Rect2(400, 275, 480, 150), Color(0, 0, 0, 0.75))
        draw_string(ThemeDB.fallback_font, Vector2(545, 345), "PAUSED", HORIZONTAL_ALIGNMENT_LEFT, -1, 46, Color.WHITE)
        draw_string(ThemeDB.fallback_font, Vector2(465, 390), "Press P to continue", HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color("#c8d6df"))

    if game_over:
        draw_rect(Rect2(360, 245, 560, 230), Color(0, 0, 0, 0.82))
        draw_string(ThemeDB.fallback_font, Vector2(535, 305), "FULL TIME", HORIZONTAL_ALIGNMENT_LEFT, -1, 40, Color.WHITE)
        draw_string(ThemeDB.fallback_font, Vector2(500, 355), "%s  %d - %d  %s" % [home_team, home_score, away_score, away_team], HORIZONTAL_ALIGNMENT_LEFT, -1, 25, Color("#f4d35e"))
        draw_string(ThemeDB.fallback_font, Vector2(470, 405), "Press R for rematch or ESC for menu", HORIZONTAL_ALIGNMENT_LEFT, -1, 20, Color("#c8d6df"))

    if message_time > 0:
        draw_rect(Rect2(480, 125, 320, 70), Color(0, 0, 0, 0.65))
        draw_string(ThemeDB.fallback_font, Vector2(535, 170), message, HORIZONTAL_ALIGNMENT_LEFT, -1, 32, Color("#f4d35e"))
